package com.mphasis.BookStoreService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.mphasis.BookStoreRepository.BookStoreRepository;
import com.mphasis.bookentity.Book;

import java.util.List;

@Service(value="bookStoreService")
@Scope(value="singleton")
public class BookStoreService implements IBookStoreService {

    @Autowired
    @Qualifier(value="bookStoreRepository")
    private BookStoreRepository bookStoreRepository;
    
    @Override
	public Book addBook(Book book) {
		
		return bookStoreRepository.save(book);
	}

	@Override
	public Book updateBook(Book book) {
		// TODO Auto-generated method stub
		return bookStoreRepository.save(book);
	}


	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return bookStoreRepository.findAll();
	}

	@Override
	public Book getBookById(Integer id) {
		
		return bookStoreRepository.findById(id).get();
	}

	@Override
	public List<Book> findByTitle(String title) {
		
		return bookStoreRepository.findByTitle(title);
	}

	@Override
	public List<Book> findByPublisher(String publisher) {
		
		return bookStoreRepository.findByPublisher(publisher);
	}

	@Override
	public List<Book> findByYear(int year) {
		// TODO Auto-generated method stub
		return bookStoreRepository.findByYear(year);
	}

	
	@Override
	public void deleteBookById(Integer id) {
		// TODO Auto-generated method stub
		bookStoreRepository.deleteById(id);
		
	}


    // Additional methods for custom queries
}

