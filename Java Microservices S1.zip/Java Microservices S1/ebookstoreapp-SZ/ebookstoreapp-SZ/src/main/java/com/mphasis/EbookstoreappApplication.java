package com.mphasis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
//import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.context.annotation.ComponentScan;

import com.mphasis.BookStoreRepository.BookStoreRepository;
import com.mphasis.bookentity.Book;

import brave.sampler.Sampler;
@EnableDiscoveryClient
@SpringBootApplication
@ComponentScan(basePackages = "com.mphasis")
public class EbookstoreappApplication implements CommandLineRunner {
	@Autowired
	@Qualifier("bookStoreRepository")
	private BookStoreRepository bookStoreRepository;

	public static void main(String[] args) {
		SpringApplication.run(EbookstoreappApplication.class, args);
		System.out.println("started");
	}
	
	@Bean
	public Sampler getSampler() {
		return Sampler.ALWAYS_SAMPLE;
	}

	
	  @Override 
	  public void run(String... args) throws Exception {
	  bookStoreRepository.save(new Book(null,"abc","xyz",1789));
	  bookStoreRepository.save(new Book(null,"python","abc",1788));
	  bookStoreRepository.save(new Book(null,"abcd","xy",1785));
	  bookStoreRepository.save(new Book(null,"abcf","x",1781));
	  
	 }
	 
	

}
