package com.mphasis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScdfSourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
