package com.mphasis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeRegistrationConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeRegistrationConsumerApplication.class, args);
	}

}
