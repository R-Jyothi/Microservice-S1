package com.mphasis.consumer;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

import com.mphasis.domain.Employee;

@Service
public class EmployeeRegistrationConsumer {
	@RabbitListener(queues={"${rabbitmq.queue.name}"})
	public void consume(Employee employee) {
		System.out.println("Message arrived! Message:"+employee);
	}

}
