package com.mphasis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
@ComponentScan(basePackages = "com.mphasis")
@SpringBootApplication
public class EmployeeRegistrationProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeRegistrationProducerApplication.class, args);
		System.out.println("started");
	}

}
