package com.mphasis.BookStoreRestController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import com.mphasis.BookStoreService.BookStoreService;
import com.mphasis.bookentity.Book;

import java.util.List;

@RestController
@Scope(value="request")

public class BookStoreRestController {

    @Autowired
    @Qualifier("bookStoreService")
    private BookStoreService bookStoreService;
    
    
    @PostMapping(value = "/books", produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.CREATED)
    public Book addBook(@RequestBody Book book) {
        return bookStoreService.addBook(book);
    }

    @PutMapping(value="/books", produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseStatus(HttpStatus.OK)
    public Book updateBook(@RequestBody Book book) {
        return bookStoreService.updateBook(book);
    }
    
    @DeleteMapping(value="/books/{id}")
    @ResponseStatus(code=HttpStatus.NO_CONTENT)
    public void deleteBookById(@PathVariable("id") Integer id) {
        bookStoreService.deleteBookById(id);
    }

    @GetMapping(value="/books",produces = {MediaType.APPLICATION_JSON_VALUE})
    public List<Book> getAllBooks() {
        return bookStoreService.getAllBooks();
    }

    @GetMapping(value="/books/{id}",produces = {MediaType.APPLICATION_JSON_VALUE})
    public Book getBookById(@PathVariable("id") Integer id) {
        return bookStoreService.getBookById(id);
    }

    

    @GetMapping(value="/books/title/{title}",produces = {MediaType.APPLICATION_JSON_VALUE})
    public List<Book> getAllBooksByTitle(@PathVariable("title") String title) {
        return bookStoreService.findByTitle(title);
    }

    @GetMapping(value="/books/publisher/{publisher}",produces = {MediaType.APPLICATION_JSON_VALUE})
    public List<Book> getAllBooksByPublisher(@PathVariable("book_publisher") String publisher) {
        return bookStoreService.findByPublisher(publisher);
    }

    @GetMapping(value="/books/year/{year}",produces = {MediaType.APPLICATION_JSON_VALUE})
    public List<Book> getAllBooksByYear(@RequestParam("year") int year) {
        return bookStoreService.findByYear(year);
    }
    // Additional methods for custom queries
}
