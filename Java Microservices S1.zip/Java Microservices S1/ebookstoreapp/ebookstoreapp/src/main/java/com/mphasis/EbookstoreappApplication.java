package com.mphasis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import com.mphasis.BookStoreRepository.BookStoreRepository;
import com.mphasis.bookentity.Book;

@EnableDiscoveryClient
@SpringBootApplication
//@ComponentScan(basePackages="com.mphasis.bookentity"+"com.mphasis.BookStoreRepository,"+ "com.mphasis.BooksStoreRestController,"+"com.mphasis.BookStoreService")
public class EbookstoreappApplication implements CommandLineRunner {
	@Autowired
	@Qualifier("bookStoreRepository")
	private BookStoreRepository bookStoreRepository;

	public static void main(String[] args) {
		SpringApplication.run(EbookstoreappApplication.class, args);
		System.out.println("started");
	}

	
	  @Override 
	  public void run(String... args) throws Exception {
	  bookStoreRepository.save(new Book(null,"abc","xyz",1789));
	  bookStoreRepository.save(new Book(null,"python","abc",1788));
	  bookStoreRepository.save(new Book(null,"abcd","xy",1785));
	  bookStoreRepository.save(new Book(null,"abcf","x",1781));
	  
	 }
	 
	

}
