package com.mphasis.BookStoreService;

import java.util.List;

import com.mphasis.bookentity.Book;

public interface IBookStoreService {
	public Book addBook (Book book);

	public Book updateBook (Book book);

	public List<Book> getAllBooks();

	public Book getBookById(Integer id); 
	public void deleteBookById(Integer id);

	public List<Book> findByTitle(String title);
    public List<Book> findByPublisher(String publisher);
    public List<Book> findByYear(int year);
    

}
